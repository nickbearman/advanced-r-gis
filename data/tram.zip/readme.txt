Tram Data Files
===============

Files stored in tram.zip, for use in Nick Bearman's course Confident Spatial Analysis and Statistics in R & GeoDa, available at https://github.com/nickbearman/confident-spatial-analysis. 

Files include:
- future_tramstops.shp
- future_tramlines.shp
- TfGMMetroRailStops.csv
- Metrolink_Lines_Functional.shp
- Metrolink_Stops_Functional.shp

File details:

	future_tramstops.shp - potential future tram stops for Manchester Metrolink, last updated by NB on 2023-06-28

	future_tramlines.shp - potential future tram line for Manchester Metrolink, last updated by NB on 2023-06-28

	TfGMMetroRailStops.csv - Metrolink Stops and Rail Stations
	- available from https://www.data.gov.uk/dataset/8faea7ee-eb7d-43dd-b1d4-f01aac4c44d3/metrolink-stops-and-rail-stations
	- downloaded on 2023-06-28
	- last updated 10 March 2020
	- Shared under Open Government License. 

	Metrolink_Lines_Functional.shp & Metrolink_Stops_Functional.shp
	- extracted from GM_Metrolink_MapData.zip
	- available from https://www.data.gov.uk/dataset/55576216-cd1d-4e2b-adcf-c87c07473373/gm-metrolink-network
	- downloaded on 2023-06-28
	- last updated 28 February 2022
	- Shared under Open Government License. 

Where relevant:
	This data is licensed under the Open Government Licence:
	<http://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/> 
	Please acknowledge the source of this information using the following attribution statement: 
	Contains Transport for Greater Manchester data.  Contains OS data © Crown copyright and database right 2023.
