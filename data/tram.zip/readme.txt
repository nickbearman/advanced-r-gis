Tram Data Files
===============

Files stored in tram.zip, for use in Nick Bearman's course Advanced R as a GIS: Spatial Analysis and Statistics, available at https://github.com/nickbearman/advanced-r-gis. 

Files include:
- Greater_Manchester_LSOA_Age_IMD.gpkg
- future_tramstops.shp
- future_tramlines.shp
- TfGMMetroRailStops.csv
- Metrolink_Lines_Functional.shp
- Metrolink_Stops_Functional.shp

File details:

	Greater_Manchester_LSOA_Age_IMD.gpkg - LSOA 2021 for Greater Manchester, plus Age (5 year groups) and IMD 2025 data, prepared as described in script-examples/data-preparation.R

	future_tramstops.shp - potential future tram stops for Manchester Metrolink, last updated by NB on 2023-06-28

	future_tramlines.shp - potential future tram line for Manchester Metrolink, last updated by NB on 2023-06-28

	TfGMMetroRailStops.csv - Metrolink Stops and Rail Stations
	- available from https://www.data.gov.uk/dataset/8faea7ee-eb7d-43dd-b1d4-f01aac4c44d3/metrolink-stops-and-rail-stations
	- downloaded on 2023-06-28
	- last updated 10 March 2020
	- Shared under Open Government License. 

	Metrolink_Lines_Functional.shp & Metrolink_Stops_Functional.shp
	- extracted from GM_Metrolink_MapData.zip
	- available from https://www.data.gov.uk/dataset/55576216-cd1d-4e2b-adcf-c87c07473373/gm-metrolink-network
	- downloaded on 2023-06-28
	- last updated 28 February 2022
	- Shared under Open Government License. 

Where relevant:
	This data is licensed under the Open Government Licence:
	<http://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/> 
	Please acknowledge the source of this information using the following attribution statement: 
	Contains Transport for Greater Manchester data.  Contains OS data © Crown copyright and database right 2025.
